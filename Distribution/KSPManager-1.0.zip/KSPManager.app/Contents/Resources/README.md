KSPManager: A Kerbal Space Program Part & Plugin Manager

KSP Manager is a native Mac OS X application designed to make it easy to manage the amazing
wealth of add-on parts and plugins for Kerbal Space Program.

- XCode project files can be found at https://github.com/JnyJny/KSPManager.git

- Standby for a binary distribution.

